<?php

namespace App\Http\Controllers;
use Spatie\GoogleCalendar\Event;

use Illuminate\Http\Request;

class GoogleController extends Controller
{
    $event=new Event();
}
